<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<!--[title]>
change title
<!-->
<title>New Zealand E-shop</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<link rel="stylesheet" type="text/css" href="style.css" />
<!--[if IE 6]>
<link rel="stylesheet" type="text/css" href="iecss.css" />
<![endif]-->
<script type="text/javascript" src="js/boxOver.js"></script>
</head>
<body>
<div id="main_container">
  <div class="top_bar">
  
  
  <div id="form">
  
  <form method="get" action="results.php" enctype="multipart/form-data">
  
  
    <div class="top_search">
      <div class="search_text">Advanced Search</div>
      <input type="text" class="search_input" name="user_query" placeholder="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Search your need"/>
      <input type="submit" value="Search" class="search_bt" name="search"/>
    </div>
    
    
    </form>
    
    </div>
    
    
    <div class="languages">
      <div class="lang_text">Languages:</div>
      <a href="#" class="lang"><img src="images/en.gif" alt="" border="0" /></a> <a href="#" class="lang"><img src="images/ch.png" alt="" border="0" /></a> </div>
  </div>
  <div id="header">
    <div id="logo"> <a href="index.php"><img src="images/logo.png" alt="" border="0" width="237" height="140" /></a> </div>
    <div class="oferte_content">
      <div class="top_divider"><img src="images/header_divider.png" alt="" width="1" height="164" /></div>
      <div class="oferta">
       
    <?php
    
    sliderdata();

?>
      </div>

      <div class="top_divider"><img src="images/header_divider.png" alt="" width="1" height="164" /></div>
    </div>
    <!-- end of sale_content-->
  </div>
  <div id="main_content">
    <div id="menu_tab">
      <div class="left_menu_corner"></div>
      <ul class="menu">
        <li><a href="index.php" class="nav1"> Home</a></li>
        <li class="divider"></li>
        <li><a href="allproducts.php" class="nav2">All Products</a></li>
        <li class="divider"></li>
        <li><a href="cart.php" class="nav5">Cart</a></li>
        <li class="divider"></li>
        <li><a href="admin_area/login.html" class="nav4">Login</a></li>
       
        
        
      </ul>
      <div class="right_menu_corner"></div>
    </div>

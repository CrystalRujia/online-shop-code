<?php

$con = mysqli_connect("localhost","id7575709_u605666432_user","31245Lrj","id7575709_u605666432_cs");

?>
